<?php
    include "connect.php";
    
    $coba = query("SELECT * FROM user");
    $art = query("SELECT * FROM artikel");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table thead {
            background-color:gray;
            color:white;
        }
        table td{
            padding:15px;
        }
    </style>
</head>
<body>
    <center>

        <div class="tabel">
            <table border="1">
                <h1>Yang sudah terregistrasi</h1>
                <thead>
                <th>id</th>
                <th>username</th>
                <th>password</th>
                <th>Aksi</th>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    foreach($coba as $get): ?>
    
                    <tr>
                        <td><?= $i+1; ?> </td>
                        <td><?= $get['username']; ?></td>
                        <td><?= $get['password']; ?></td>
                        <td><a href="hapus'ubah.php?id=<?= $get["id"];?> "onclick=" return confrim('yakin?');">Hapus</a></td>
                        <?php $i++ ?>
                    </tr>
                  <?php 
                    endforeach;
                  ?>
                </tbody>
            </table>
        </div>
                </br></br></br>
        <div class="tabel">
            <table border="1">
                <h1>berhasil terupload</h1>
                <thead>
                <th>id</th>
                <th>caption</th>
                <th>Aksi</th>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    foreach($art as $get): ?>
    
                    <tr>
                        <td><?= $i+1; ?> </td>
                        <td><?= $get['caption']; ?></td>
                        <td><a href="hapus'ubah.php?id=<?= $get["id"];?> "onclick=" return confrim('yakin?');">Hapus</a>
                        <a href="ubah.php?id=<?= $get["id"];?> "onclick=" return confrim('yakin?');"> / Ubah</a></td>
                        <?php $i++ ?>
                    </tr>
                  <?php 
                    endforeach;
                  ?>
                </tbody>
            </table>
        </div>
    </center>
</body>
</html>