function settingsmenutoggle(elemenid,class_nama,class_target){
    var x=document.getElementById(elemenid);
    if(x.className==class_nama){
        x.className=class_target;
    }else{
        x.className=class_nama;
    }
}