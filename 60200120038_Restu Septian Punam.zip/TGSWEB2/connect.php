<?php 
    $connect = mysqli_connect("localhost", "root", "" , "databasetugas1");

    if($connect){
        echo"Berhasil Terhubung";

    }
    else{
        echo "gagal terhubung";
    }

    function query($query){
        global $connect;
        $result = mysqli_query($connect, $query);
        $rows =[];
        while ($row = mysqli_fetch_assoc ($result)){
            $rows[] = $row;
        }
        return $rows;
    }

?>