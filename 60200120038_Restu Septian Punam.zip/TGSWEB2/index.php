<?php
require 'functions.php';

$caption = query("SELECT * FROM artikel");
// Cek apakah tombol submit sudah dipencet atau belum
if (isset($_POST["submit"])) {
    // var_dump($_POST);

    if (tambah($_POST) > 0) {

        echo " 
        <script>
            
            document.location.href='index.php';
        </script> ";
    } else {
        echo " 
        <script>
            
            document.location.href='index.php';
        </script> ";
        echo mysqli_error($conn);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="main.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="JPG/orang.png">
    <title>Go bloG</title>
    <link rel="stylesheet" href="css/upload.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/set_artikel.css">
    <script src="https://kit.fontawesome.com/46c50fae66.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/7bd30e020c.js" crossorigin="anonymous"></script> 
</head>
<body>
    <nav>
        <div class="nav-left">
            <img src="images/logo.png" class="logo">
            <ul>
                <li><img src="images/notification.png"></li>
                <li><img src="images/inbox.png"></li>
                <li><img src="images/video.png"></li>
            </ul>
        </div>
        <div class="nav-right">

            <div class="search-box">
                <img src="images/search.png">
                <input type="text" placeholder="search">
            </div>
            <div class="nav-user-icon online" onclick="settingsmenutoggle('pop-up','settingmenu','settingmenu-height')" >
                <img src="images/profilem.jpg">
            </div>

        </div>
        <!------------setting - menu------------>
        <div class="settingmenu" id="pop-up">
            <div class="setting-menu-iner">
                <div class="user-prifile">
                    <img src="images/profilem.jpg">
                    <div>
                        <p>Restu Septian Punam</p>
                        <a href="#">See your profile</a>
                    </div>
                </div>
                <hr>
                <div class="user-prifile">
                    <img src="images/feedback.png">
                    <div>
                        <p>GIve Feedback</p>
                        <a href="#">Help us to improve the new design</a>
                    </div>
                </div>
                <hr>
                <div class="settinglinks">
                    <img src="images/setting.png" class="setting-icon">
                    <a href="#">Setting & Privacy <img src="images/arrow.png" width="10px"></a>
                </div>
                <div class="settinglinks">
                    <img src="images/help.png" class="setting-icon">
                    <a href="#">Help & Support <img src="images/arrow.png" width="10px"></a>
                </div>
                <div class="settinglinks">
                    <img src="images/display.png" class="setting-icon">
                    <a href="#">Display & accessibility <img src="images/arrow.png" width="10px"></a>
                </div>
                <div class="settinglinks">
                    <img src="images/logout.png" class="setting-icon">
                    <a href="#">Log out <img src="images/arrow.png" width="10px"></a>
                </div>
                <div class="settinglinks">
                    <a href="database.php" target="blank">Admin<img src="images/arrow.png" width="10px"></a>
                </div>
                
            </div>
  
        </div>
    </nav>

    <div class="container">
        <!------------left-sidebar------------>
        <div class="left-sidebar">
            <div class="imp-link">
                <a href="#"><img src="images/news.png">latest News</a>
                <a href="#"><img src="images/friends.png">friends</a>
                <a href="#"><img src="images/group.png">Group</a>
                <a href="#"><img src="images/marketplace.png">marketplace</a>
                <a href="#"><img src="images/watch.png">watch</a>
                <a href="#">See More</a>
            </div>
            <div class="short-link">
                <p>Your Shortcuts</p>
                <a href="#"><img src="images/shortcut-1.png">web Wevelopers</a>
                <a href="#"><img src="images/shortcut-2.png">Web Design cours</a>
                <a href="#"><img src="images/shortcut-3.png">Full Stack Development</a>
                <a href="#"><img src="images/shortcut-4.png">Web Experts</a>
            </div>
        </div>
        <!------------main content------------>
        <div class="main-content">

            <div class="story-galer">
                <div class="story story1">
                    <img src="images/upload.png">
                    <p>Alison</p>
                </div>
                <div class="story story2">
                    <img src="images/header.jpg">
                    <p>james</p>
                </div>
                <div class="story story3">
                    <img src="images/header.jpg">
                    <p>fredy</p>
                </div>
                <div class="story story4">
                    <img src="images/header.jpg">
                    <p>marly</p>
                </div>
                <div class="story story5">
                    <img src="images/header.jpg">
                    <p>minica</p>
                </div>
            </div>

            <div class="write-post-container">
                <div class="user-prifile">
                    <img src="images/profilem.jpg">
                    <div>
                        <p>Restu Septian Punam</p>
                        <small>Public <i class="fas fa-caret-down"></i></small>
                    </div>
                </div>

                <div class="post-input-container">
                <form action="" method="post">
                    <textarea name="caption" id="caption" rows="3" placeholder="Apa yang ada dipikiranmu sekarang?"required></textarea>
                    <button class="submit-button" type="submit" name="submit">Kirim <i class="fas fa-sign-in-alt"></i> </button>
                    <div class="add-post-link">
                        <a href="#"><img src="images/live-video.png">Live Video</a>
                        <a href="#"><img src="images/photo.png">Photo/Video</a>
                        <a href="#"><img src="images/feeling.png">Feling/Activity</a>
                    </div>
                </div>
                </form>
                <?php $i = 1; ?>
                            <?php foreach ($caption as $cap) : ?>
                                <div class="artikel">
                                    <div class="head-artikel">
                                        <div class="right-side">
                                        <div class="foto-upload">
                                                <img src="images/profilem.jpg" alt="">
                                            </div>
                                            <div class="user-prifilecoment">
                                            <div>
                                            <p>Restu Septian Punam</p>
                                            <small>Public <i class="fas fa-caret-down"></i></small>
                                            </div>
                                            </div>
                                        </div>

                                        <div class="set">
                                            <div id="sett" onclick="change_class3(this,'but-set','but-set2'); changeclass('but-setting','butset','butset2') " class="but-set">
                                                <div  class="butset">
                                                    <div class="icon-set">
                                                    <i class="fa-solid fa-bars"></i> 
                                                    </div>
                                                    <a href="hapus.php?id=<?= $cap["id"]; ?>">  <button class="Hapus"><i class="fas fa-trash"></i><p>Hapus</p></button></a>
                                                    <a href="ubah.php?id=<?= $cap["id"]; ?>"> <button class="ubah"><i class="fas fa-trash"></i><p>Ubah</p></button></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="body-artikel">
                                        <p><?= $cap["caption"]; ?></p>
                                    </div>
                                </div>

                            <?php $i++; ?>
                         <?php endforeach; ?>
            </div>

        </div>
        <!------------right-sidebar------------>
        <div class="right-sidebar">

            <div class="sidebar-title">
                <h4>Events</h4>
                <a href="#">See All</a>
            </div>

            <div class="event">
                <div class="left-event">
                    <h3>18</h3>
                    <span>March</span>
                </div>
                <div class="right-event">
                    <h4>Social Media</h4>
                    <p><i class="fa-solid fa-location-dot"></i> Willson Tech Park</p>
                    <a href="#">More Info</a>
                </div>
            </div>
            <div class="event">
                <div class="left-event">
                    <h3>22</h3>
                    <span>june</span>
                </div>
                <div class="right-event">
                    <h4>Mobile Marketing</h4>
                    <p><i class="fa-solid fa-location-dot"></i> Willson Tech Park</p>
                    <a href="#">More Info</a>
                </div>
            </div>
            <div class="sidebar-title">
                <h4>Advertisment</h4>
                <a href="#">Close</a>
            </div>
            <img src="images/advertisement.png" class="sidebar-ads">

            <div class="sidebar-title">
                <h4>Conversation</h4>
                <a href="#">Hide Chat</a>
            </div>

            <div class="online-list">
                <div class="online">
                    <img src="images/kyoko.png">
                </div>
                <p>Nao Yorihime</p>
            </div>
            <div class="online-list">
                <div class="online">
                    <img src="images/HarukaKasugano.png">
                </div>
                <p>Haruka Kasugano</p>
            </div>
            <div class="online-list">
                <div class="online">
                    <img src="images/SoraKasugano.png">
                </div>
                <p>Sora Kasugano</p>
            </div>

        </div>
    </div>
    <script src="main.js"></script>
</body>
</html>