<?php
require 'functions.php';


// ambil data di url
    $id = $_GET["id"];
    $result = mysqli_query($conn, "SELECT * FROM artikel WHERE id=$id");
    $data = mysqli_fetch_assoc($result);


// Cek apakah tombol submit sudah dipencet atau belum
if (isset($_POST["submit"])) {

    if (ubah($_POST) > 0) {

        echo " 
        <script>
            alert('Data Berhasil diubah');
            document.location.href='index.php';
        </script> ";
    } else {
        echo " 
        <script>
            alert('Data Tidak Berhasil diubah');
            document.location.href='ubah.php';
        </script> ";
        echo mysqli_error($conn);
    }
}


    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/datastyle.css">
    <link rel="stylesheet" href="css/ubahdata.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Data</title>
  
</head> 
<body>
        </div>
    </div>
    <div class="body">
            <div class="logarea arealog" id="pop-up-form">
                <button class="logclose" onclick="change_class2('pop-up-form','logarea arealog')" >
                    &times
                </button>
                    <h1 class="logjudul">
                        Go bloG <i class="fas fa-user"></i>
                    </h1>
                  

                <form action="" method="POST">
                        <center>
                            <table class="form" >
                                <input type="hidden" name="id" value="<?= $data["id"];?>">
                                <tr>
                                    <td>
                                    <textarea class="box-area" name="caption" id="caption" cols="30" rows="10" ><?= $data["caption"];?></textarea>
                                    </td>
                                </tr>
                                  
                                <tr>
                                    <td>
</br>
                                    <button class="submit-button" type="submit" name="submit">Simpan</button>
                                    </td>
                                </tr>

                            </table>
                            
                        </center>

                    </form>
            </div>
        
    
</body>
</html>